
  # Public Page and Admin Login

  This is a code bundle for Public Page and Admin Login. The original project is available at https://www.figma.com/design/pszLh1kn45dXqpyrrbUMIg/Public-Page-and-Admin-Login.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  